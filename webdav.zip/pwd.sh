echo "===========================================" | lolcat
echo "Author   : </>./Riztrexx</>" | lolcat
echo "WhatsApp : +62-878-1110-2801" | lolcat
echo "Blog     : https://blog-meta-cyber.web.app" | lolcat
echo "===========================================" | lolcat
echo ""
echo "[1] Tools Deface Website"
echo "[2] Tools Untuk Merusak HP Anda"
read -p "[?] Pilih : " pas;
if [ $pas = 1 ]
then
clear
fi
if [ $pas = 2 ]
then
clear
echo "KOK KAMU GOBLOK?"
sleep 5
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
figlet "GOBLOK"
echo "01.01 04:16 </>./Riztrexx</>"
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
xdg-open https://blog-meta-cyber.web.app
fi
